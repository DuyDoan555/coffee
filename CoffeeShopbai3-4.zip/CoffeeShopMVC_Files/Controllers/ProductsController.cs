using Microsoft.AspNetCore.Mvc;
using coffeeshop.Models;
using System.Collections.Generic;
using System.Linq;

namespace coffeeshop.Controllers
{
    public class ProductsController : Controller
    {
        private static List<Product> products = new List<Product>
        {
            new Product { Id = 1, Name = "Espresso", Detail = "Strong and bold coffee.", Price = 2.99M, ImageUrl = "/assets/images/espresso.jpg" },
            new Product { Id = 2, Name = "Cappuccino", Detail = "Smooth and creamy.", Price = 3.99M, ImageUrl = "/assets/images/cappuccino.jpg" },
            new Product { Id = 3, Name = "Latte", Detail = "Mild and milky.", Price = 4.49M, ImageUrl = "/assets/images/latte.jpg" }
        };

        public IActionResult Shop()
        {
            return View(products);
        }

        public IActionResult Detail(int id)
        {
            var product = products.FirstOrDefault(p => p.Id == id);
            if (product != null)
                return View(product);
            return NotFound();
        }
    }
}