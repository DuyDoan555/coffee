using Microsoft.AspNetCore.Mvc;
using coffeeshop.Models;
using System.Collections.Generic;

namespace coffeeshop.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var trendingProduct = new Product
            {
                Id = 1,
                Name = "Espresso",
                Detail = "Strong and bold coffee.",
                Price = 2.99M,
                ImageUrl = "/assets/images/espresso.jpg"
            };
            return View(trendingProduct);
        }
    }
}